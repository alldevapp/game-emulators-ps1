# Atari Jaguar

## Code example

```html
<div style='width:640px;height:480px;max-width:100%'>
    <div id='game'></div>
</div>

<script type='text/javascript'>
    EJS_player = '#game';
    
    // Can also be virtualjaguar
    EJS_core = 'jaguar';
    
    // URL to Game rom
     
    EJS_gameUrl = '';
    
    /*
     *  Path to the WASM / JS files
     *  HAS TO BE in the same directory.
     */
    
    EJS_pathtodata = 'data/';
    
</script>

<script src='data/loader.js'></script>
```

### CORES

The *jaguar* system supports 1 core
- `virtualjaguar`

If set to `jaguar`, emulator will use the `virtualjaguar` core.
